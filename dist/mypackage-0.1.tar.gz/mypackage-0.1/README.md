#mypackage
This library is for recursion and sorting using Python package.

##building this package locally
'python setup.py sdist'

##installing this package from GitHub
'pip install git+https://github.com/Kwazi083/package-root'

##updating this package from GitHub
'pip install --upgrade git+https://github.com/Kwazi083/package-root'
